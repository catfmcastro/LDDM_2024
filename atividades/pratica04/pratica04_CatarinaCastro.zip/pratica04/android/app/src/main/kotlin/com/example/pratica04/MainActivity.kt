package com.example.pratica04

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

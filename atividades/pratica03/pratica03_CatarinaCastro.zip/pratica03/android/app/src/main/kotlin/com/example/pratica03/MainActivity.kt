package com.example.pratica03

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

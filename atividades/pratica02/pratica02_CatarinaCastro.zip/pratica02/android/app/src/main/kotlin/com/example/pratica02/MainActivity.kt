package com.example.pratica02

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

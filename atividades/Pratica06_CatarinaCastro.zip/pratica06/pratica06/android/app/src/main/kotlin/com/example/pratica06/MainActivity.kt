package com.example.pratica06

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
